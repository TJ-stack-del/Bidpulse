import Link from "next/link";
import { SignupForm } from "./SignupForm";

export default function SignupPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-surface px-margin-mobile">
      <div className="w-full max-w-[420px] bg-surface-container-lowest border border-outline-variant rounded-xl p-8">
        <h1 className="text-headline-md text-on-surface mb-1">Create your BidPulse account</h1>
        <p className="text-body-md text-on-surface-variant mb-6">
          This creates a new organization with you as its owner.
        </p>
        <SignupForm />
        <p className="text-body-md text-on-surface-variant mt-6 text-center">
          Already have an account?{" "}
          <Link href="/login" className="text-secondary font-bold">
            Log in
          </Link>
        </p>
      </div>
    </div>
  );
}
