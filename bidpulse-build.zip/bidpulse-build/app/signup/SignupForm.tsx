"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

// NOTE: this assumes Supabase Auth → Providers → Email → "Confirm email"
// is turned OFF during early development, so signUp() returns an active
// session immediately. If email confirmation is required, auth.uid()
// won't be available until the user clicks the confirmation link in a
// separate session — the organizations/team_members insert below would
// need to move to a server-side callback route instead.

export function SignupForm() {
  const [fullName, setFullName] = useState("");
  const [orgName, setOrgName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();
  const supabase = createClient();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    // 1. Create the auth user.
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (signUpError || !signUpData.user) {
      setError(signUpError?.message ?? "Sign up failed.");
      setSubmitting(false);
      return;
    }

    // 2. Create their organization.
    const { data: org, error: orgError } = await supabase
      .from("organizations")
      .insert({ name: orgName })
      .select()
      .single();

    if (orgError || !org) {
      setError(
        `Account created, but the organization couldn't be set up (${orgError?.message}). Try logging in and contact support.`
      );
      setSubmitting(false);
      return;
    }

    // 3. Link them to it as the owner.
    const { error: memberError } = await supabase.from("team_members").insert({
      org_id: org.id,
      auth_user_id: signUpData.user.id,
      full_name: fullName,
      email,
      role: "contractor_owner",
    });

    setSubmitting(false);

    if (memberError) {
      setError(
        `Account and organization created, but linking your profile failed (${memberError.message}). Try logging in and contact support.`
      );
      return;
    }

    router.push("/dashboard");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div>
        <label className="text-label-md text-on-surface-variant block mb-1">Your name</label>
        <input
          type="text"
          required
          value={fullName}
          onChange={(e) => setFullName(e.target.value)}
          className="w-full px-3 py-2 rounded border border-outline-variant bg-surface text-body-md text-on-surface focus:border-secondary outline-none"
        />
      </div>
      <div>
        <label className="text-label-md text-on-surface-variant block mb-1">
          Organization name
        </label>
        <input
          type="text"
          required
          value={orgName}
          onChange={(e) => setOrgName(e.target.value)}
          placeholder="e.g. Acme Facilities Services"
          className="w-full px-3 py-2 rounded border border-outline-variant bg-surface text-body-md text-on-surface focus:border-secondary outline-none"
        />
      </div>
      <div>
        <label className="text-label-md text-on-surface-variant block mb-1">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full px-3 py-2 rounded border border-outline-variant bg-surface text-body-md text-on-surface focus:border-secondary outline-none"
        />
      </div>
      <div>
        <label className="text-label-md text-on-surface-variant block mb-1">Password</label>
        <input
          type="password"
          required
          minLength={6}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full px-3 py-2 rounded border border-outline-variant bg-surface text-body-md text-on-surface focus:border-secondary outline-none"
        />
      </div>

      {error && <p className="text-body-md text-error">{error}</p>}

      <button
        type="submit"
        disabled={submitting}
        className="w-full py-3 px-4 bg-primary text-on-primary rounded text-label-md hover:bg-on-background transition-colors disabled:opacity-40"
      >
        {submitting ? "Creating account…" : "Create account"}
      </button>
    </form>
  );
}
