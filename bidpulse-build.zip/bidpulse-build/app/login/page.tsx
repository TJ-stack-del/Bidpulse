import Link from "next/link";
import { LoginForm } from "./LoginForm";

export default function LoginPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-surface px-margin-mobile">
      <div className="w-full max-w-[420px] bg-surface-container-lowest border border-outline-variant rounded-xl p-8">
        <h1 className="text-headline-md text-on-surface mb-1">Log in to BidPulse</h1>
        <p className="text-body-md text-on-surface-variant mb-6">
          Enter your email and password to continue.
        </p>
        <LoginForm />
        <p className="text-body-md text-on-surface-variant mt-6 text-center">
          Don&apos;t have an account?{" "}
          <Link href="/signup" className="text-secondary font-bold">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
