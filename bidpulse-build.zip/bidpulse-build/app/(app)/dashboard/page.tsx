import { createClient } from "@/lib/supabase/server";
import { AppShell } from "@/components/ui/AppShell";
import Link from "next/link";

// Converted from mockups-reference/bidpulse_dashboard_desktop/code.html
// Where login/signup send you after a successful sign-in.

export default async function DashboardPage() {
  const supabase = await createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return (
      <AppShell activePath="/dashboard">
        <p className="text-body-md text-on-surface-variant mt-6">
          Please <Link href="/login" className="text-secondary font-bold">log in</Link> to view your dashboard.
        </p>
      </AppShell>
    );
  }

  const { data: member } = await supabase
    .from("team_members")
    .select("org_id, full_name")
    .eq("auth_user_id", user.id)
    .single();

  if (!member) {
    return (
      <AppShell activePath="/dashboard">
        <p className="text-body-md text-error mt-6">
          No team_members record found for this account — see README step 12.
        </p>
      </AppShell>
    );
  }

  const { data: bids } = await supabase
    .from("bids")
    .select("id, title, agency, due_date, stage, status")
    .eq("org_id", member.org_id)
    .order("due_date", { ascending: true });

  const now = new Date();
  const upcoming = (bids ?? []).filter(
    (b) => b.due_date && new Date(b.due_date) > now && b.status !== "submitted"
  );

  return (
    <AppShell activePath="/dashboard">
      <div className="mt-6">
        <h1 className="text-headline-lg text-on-surface mb-1">
          Dashboard
        </h1>
        <p className="text-body-md text-on-surface-variant">
          Welcome back, {member.full_name}. You have {upcoming.length} deadline
          {upcoming.length === 1 ? "" : "s"} approaching.
        </p>
      </div>

      <div className="bg-surface-container-lowest border border-outline-variant rounded-xl p-6 mt-4">
        <h2 className="text-title-lg text-on-surface mb-4">Active Bids</h2>
        {!bids || bids.length === 0 ? (
          <p className="text-body-md text-on-surface-variant">
            No bids yet. Start one from the{" "}
            <Link href="/intake" className="text-secondary font-bold">
              intake screen
            </Link>
            .
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-body-md">
              <thead className="bg-surface-container-low">
                <tr>
                  <th className="text-left px-3 py-2 text-label-md text-on-surface-variant">Title</th>
                  <th className="text-left px-3 py-2 text-label-md text-on-surface-variant">Agency</th>
                  <th className="text-left px-3 py-2 text-label-md text-on-surface-variant">Stage</th>
                  <th className="text-left px-3 py-2 text-label-md text-on-surface-variant">Due</th>
                </tr>
              </thead>
              <tbody>
                {bids.map((bid) => (
                  <tr key={bid.id} className="border-t border-outline-variant">
                    <td className="px-3 py-2 text-on-surface">{bid.title}</td>
                    <td className="px-3 py-2 text-on-surface-variant">{bid.agency}</td>
                    <td className="px-3 py-2 text-on-surface-variant capitalize">
                      {bid.stage.replace(/_/g, " ")}
                    </td>
                    <td className="px-3 py-2 text-on-surface-variant">
                      {bid.due_date ? new Date(bid.due_date).toLocaleDateString() : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
