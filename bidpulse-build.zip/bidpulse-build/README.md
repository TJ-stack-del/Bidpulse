# BidPulse — Build Guide

Full 6-stage procurement intelligence platform, built from 43 Stitch mockups
in `mockups-reference/` plus the extended schema in `schema.sql`.

Stack: **Next.js 15 (App Router, TypeScript) + Tailwind + Supabase (Postgres, Auth, Storage) + Vercel.**

---

## 0. What's in this folder

```
bidpulse-build/
├── README.md                    ← you are here
├── schema.sql                   ← full Postgres schema, run this first
├── package.json
├── tailwind.config.ts           ← design tokens copied 1:1 from DESIGN.md
├── app/
│   ├── globals.css
│   └── (app)/
│       └── intake/
│           ├── page.tsx         ← WORKED EXAMPLE: mockup → real page
│           └── IntakeActions.tsx
├── components/ui/
│   ├── AppShell.tsx              ← shared header/nav, used on every screen
│   └── LifecycleStepper.tsx      ← shared 6-stage stepper, used on every screen
├── lib/supabase/
│   ├── client.ts                 ← browser client
│   └── server.ts                 ← server-component client
└── mockups-reference/            ← your original 43 screens + DESIGN.md, untouched
```

**How to use this with Claude Code:** open this whole `bidpulse-build/` folder
as your project root in Claude Code Desktop, then work through Phases 1–6
below. Tell Claude Code things like *"convert
mockups-reference/compliance_matrix_desktop/code.html into
app/(app)/compliance/page.tsx following the same pattern as the intake
page"* — it can read the mockup HTML, the schema, and the existing
converted pages for context, and repeat the pattern.

---

## 1. One-time setup

1. **Create the Next.js project shell** (run once, in an empty folder, then
   copy these files in over the top):
   ```bash
   npx create-next-app@latest bidpulse --typescript --tailwind --app
   cd bidpulse
   npm install @supabase/supabase-js @supabase/ssr jspdf jspdf-autotable
   npm install -D @tailwindcss/forms
   ```
   Then copy everything from this `bidpulse-build/` folder into it
   (overwrite `tailwind.config.ts`, `app/globals.css`, `package.json`).

2. **Create a Supabase project** at supabase.com → note your Project URL
   and anon key.

3. **Run the schema:** Supabase dashboard → SQL Editor → paste all of
   `schema.sql` → Run. This creates every table, the enums, RLS policies,
   and the `rfp-documents` storage bucket.

4. **Environment variables** — create `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   ```

5. **Enable Supabase Auth** (Email/Password is enough to start) — this is
   what `team_members.auth_user_id` links against.

6. **Run it:**
   ```bash
   npm run dev
   ```
   Visit `localhost:3000/intake` — you should see the worked-example page
   render with empty fields (no bid yet). Once you insert a row into
   `bids` in the Supabase table editor, `localhost:3000/intake?bid=<that-id>`
   will populate it.

---

## 2. The conversion pattern (repeat this 42 more times)

Every mockup in `mockups-reference/<screen_name>/code.html` is a
self-contained Tailwind CDN page. `app/(app)/intake/page.tsx` shows the
full conversion. The recipe:

1. Open `mockups-reference/<screen>/code.html` next to the new page file.
2. The Tailwind class names in the mockup (`bg-surface-container-lowest`,
   `text-headline-lg`, etc.) already match the tokens in
   `tailwind.config.ts` — copy the JSX structure across almost verbatim,
   converting `class=` → `className=` and closing self-closing tags.
3. Delete the `<header>` / desktop `<nav>` / mobile bottom `<nav>` — wrap
   the page in `<AppShell activePath="/whatever">` instead.
4. If the screen shows the 6-stage stepper, replace it with
   `<LifecycleStepper currentStage={N} />`.
5. Replace hardcoded placeholder copy (agency names, dollar figures) with
   real fields from a Supabase query.
6. Anything interactive (buttons that mutate data, checkboxes, forms)
   goes in a small sibling `"use client"` component, like
   `IntakeActions.tsx` — keep the page itself a server component so data
   fetching stays simple and fast.
7. Every state-changing action that matters for compliance/legal
   purposes (attestations, sign-offs, submissions, exports) should also
   insert a row into `audit_log`. Never update or delete audit_log rows —
   that's what makes it a real audit trail.

---

## 3. Route map — build in this order

### Phase 1 — Platform shell + Auth (do first, everything depends on it)
- `middleware.ts` — Supabase session refresh (see Supabase's `@supabase/ssr` docs for the standard snippet)
- `/login`, `/signup`
- `/dashboard` ← `bidpulse_dashboard`
- `components/ui/AppShell.tsx` — done
- `components/ui/LifecycleStepper.tsx` — done

### Phase 2 — Stage 1: Discovery & Intake
- `/intake` ← `rfp_intake_attestation` — **done, see worked example**
- `/opportunities/[id]` ← `matched_opportunities_detail`

### Phase 3 — Stage 2: Compliance Review
- `/compliance` ← `compliance_review`
- `/compliance/matrix` ← `compliance_matrix_desktop`
- `/compliance/[itemId]` ← `compliance_check_detail_desktop` / `_mobile`

### Phase 4 — Stage 3: Assembly & Drafting
- `/assembly` ← `assembly_drafting_desktop` / `_mobile`
- `/fit-score/[bidId]` ← `fit_analysis_detail`

### Phase 5 — Stage 4: Quality & Admin Audit
- `/admin` ← `admin_operations_dashboard`
- `/admin/review` ← `admin_review_audit`
- `/admin/sign-off` ← `admin_audit_sign_off_desktop` / `_mobile`
- `/admin/audit-log` ← `audit_log_export_desktop` / `_mobile`
- `/deliverables/sign-off` ← `deliverables_sign_off`

### Phase 6 — Stage 5: Client Review
- `/review/portal` ← `client_review_portal_desktop` / `_mobile`
- `/review/feedback` ← `client_review_feedback` / `_desktop`

### Phase 7 — Stage 6: Submission Execution
- `/submit` ← `submission_execution` / `_desktop`
- `/submit/receipt` ← `submission_receipt_desktop` / `_mobile`

### Phase 8 — Cross-cutting platform pages (build alongside whichever stage needs them)
- `/settings/security` ← `security_settings_desktop` / `_mobile`
- `/settings/team` ← `team_management_desktop`, `team_directory_mobile`, `member_access_detail_mobile`
- `/settings/roles` ← `role_permissions_desktop`
- `/notifications` ← `notification_center_desktop`, `notifications_mobile`
- `/analytics` ← `analytics_insights_desktop` / `_mobile`
- `/market-intelligence` ← `market_intelligence_desktop`
- `/docs/api` ← `api_documentation_desktop` / `_mobile`, `api_documentation_rate_limiting_*`

Reference `bidpulse_fulfillment_flow/code.html` any time the overall
stage-to-stage flow is unclear — it reads as a flow-diagram overview of
how the 6 stages connect.

---

## 4. Notes carried over from the original PRD

- **No automated scraping.** `matched_opportunities` is populated from
  manually-logged solicitations (by staff or contractors), scored by
  whatever matching logic you plug in — not by scraping external sites.
- **No unlinked calculators.** Every score (fit_score, match_score) must
  bind to a real `bids` row — don't build a standalone calculator screen.
- **No upsell banners.** Keep the UI free of promotional clutter per the
  mockups' minimal, "industrial-grade" aesthetic in DESIGN.md.

## 5. Suggested build order for auth/permissions

`role_permissions` table already seeds four roles
(`platform_admin`, `contractor_owner`, `contractor_member`,
`client_reviewer`). Gate `/admin/*` routes server-side by checking the
current user's `team_members.role` against `role_permissions.can_view_admin`
before rendering — don't rely on hiding nav links alone.
